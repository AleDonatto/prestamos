<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Estimas extends Model
{
    use HasFactory;

    protected $table = 'estimas';
    protected $primaryKey = 'id';

}
