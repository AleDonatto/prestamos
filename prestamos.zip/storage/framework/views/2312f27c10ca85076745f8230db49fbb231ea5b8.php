<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estimas</title>
</head>
<body>
    <style>
        table, th, td {
            border: 1px solid black !important;
            border-collapse: collapse !important;
        }

        table{
            width: 100%;
            margin-bottom: 35px;
        }
    </style>
    <main>
        <div>
            <table>
                <thead>
                    <tr>
                        <th>Horario</th>
                        <th>Lunes</th>
                        <th>150</th>
                        <th>$</th>
                        <th>200</th>
                        <th>$</th>
                        <th>250</th>
                        <th>$</th>
                        <th>300</th>
                        <th>$</th>
                        <th>350</th>
                        <th>$</th>
                        <th>400</th>
                        <th>$</th>
                        <th>450</th>
                        <th>$</th>
                        <th>500</th>
                        <th>$</th>
                        <th>Total</th>
                        <th>TA</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $lunes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataEstima): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td><?php echo e($dataEstima->nombreMunicipio); ?></td>
                        <td><?php echo e($dataEstima->nPrimerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoPrimerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nSegundoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoSegundoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nTercerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoTercerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nCuartoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoCuartoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nQuintoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoQuintoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nSextoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoSextoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nSeptimoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoSeptimoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nOctavoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoOctavoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->totalMonto); ?></td>
                        <td><?php echo e($dataEstima->totalAbonos); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div>
            <table>
                <thead>
                    <tr>
                        <th>Horario</th>
                        <th>Martes</th>
                        <th>150</th>
                        <th>$</th>
                        <th>200</th>
                        <th>$</th>
                        <th>250</th>
                        <th>$</th>
                        <th>300</th>
                        <th>$</th>
                        <th>350</th>
                        <th>$</th>
                        <th>400</th>
                        <th>$</th>
                        <th>450</th>
                        <th>$</th>
                        <th>500</th>
                        <th>$</th>
                        <th>Total</th>
                        <th>TA</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $martes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataEstima): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td><?php echo e($dataEstima->nombreMunicipio); ?></td>
                        <td><?php echo e($dataEstima->nPrimerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoPrimerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nSegundoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoSegundoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nTercerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoTercerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nCuartoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoCuartoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nQuintoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoQuintoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nSextoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoSextoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nSeptimoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoSeptimoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nOctavoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoOctavoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->totalMonto); ?></td>
                        <td><?php echo e($dataEstima->totalAbonos); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div>
            <p><?php echo e($miercoles); ?></p>
            <table>
                <thead>
                    <tr>
                        <th>Horario</th>
                        <th>Miercoles</th>
                        <th>150</th>
                        <th>$</th>
                        <th>200</th>
                        <th>$</th>
                        <th>250</th>
                        <th>$</th>
                        <th>300</th>
                        <th>$</th>
                        <th>350</th>
                        <th>$</th>
                        <th>400</th>
                        <th>$</th>
                        <th>450</th>
                        <th>$</th>
                        <th>500</th>
                        <th>$</th>
                        <th>Total</th>
                        <th>TA</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $miercoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataEstima): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td><?php echo e($dataEstima->nombreMunicipio); ?></td>
                        <td><?php echo e($dataEstima->nPrimerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoPrimerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nSegundoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoSegundoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nTercerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoTercerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nCuartoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoCuartoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nQuintoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoQuintoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nSextoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoSextoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nSeptimoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoSeptimoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nOctavoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoOctavoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->totalMonto); ?></td>
                        <td><?php echo e($dataEstima->totalAbonos); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td>Totales</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div>
            <table>
                <thead>
                    <tr>
                        <th>Horario</th>
                        <th>Jueves</th>
                        <th>150</th>
                        <th>$</th>
                        <th>200</th>
                        <th>$</th>
                        <th>250</th>
                        <th>$</th>
                        <th>300</th>
                        <th>$</th>
                        <th>350</th>
                        <th>$</th>
                        <th>400</th>
                        <th>$</th>
                        <th>450</th>
                        <th>$</th>
                        <th>500</th>
                        <th>$</th>
                        <th>Total</th>
                        <th>TA</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $jueves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataEstima): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td><?php echo e($dataEstima->nombreMunicipio); ?></td>
                        <td><?php echo e($dataEstima->nPrimerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoPrimerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nSegundoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoSegundoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nTercerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoTercerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nCuartoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoCuartoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nQuintoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoQuintoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nSextoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoSextoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nSeptimoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoSeptimoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nOctavoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoOctavoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->totalMonto); ?></td>
                        <td><?php echo e($dataEstima->totalAbonos); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
        <div>
            <table>
                <thead>
                    <tr>
                        <th>Horario</th>
                        <th>Viernes</th>
                        <th>150</th>
                        <th>$</th>
                        <th>200</th>
                        <th>$</th>
                        <th>250</th>
                        <th>$</th>
                        <th>300</th>
                        <th>$</th>
                        <th>350</th>
                        <th>$</th>
                        <th>400</th>
                        <th>$</th>
                        <th>450</th>
                        <th>$</th>
                        <th>500</th>
                        <th>$</th>
                        <th>Total</th>
                        <th>TA</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $viernes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataEstima): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td><?php echo e($dataEstima->nombreMunicipio); ?></td>
                        <td><?php echo e($dataEstima->nPrimerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoPrimerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nSegundoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoSegundoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nTercerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoTercerPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nCuartoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoCuartoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nQuintoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoQuintoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nSextoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoSextoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nSeptimoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoSeptimoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->nOctavoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->montoOctavoPrestamo); ?></td>
                        <td><?php echo e($dataEstima->totalMonto); ?></td>
                        <td><?php echo e($dataEstima->totalAbonos); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html><?php /**PATH C:\laragon\www\prestamos\resources\views//formatos/EstimasFormat.blade.php ENDPATH**/ ?>