<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body>
    <style>
    .invisiblexd {
        border:white solid 1px;
    }
    .cajaExt{
        position: relative;
    }/* center class for add style in div */
    .cajaFirma{
        width:250px;
        position: absolute;
        top: 8%; 
        left: 50%;
        transform: translate(-50%, -50%);
        margin-top: 10px; 
        border-top:solid black 1px;
    }
    @page {
		margin-left: 0.5cm;
		margin-right: 0;
	}
    .page-break {
        page-break-after: always;
    }

    .font-size-10{
        font-size: 0.60rem;
    }

    .font-size-9{
        font-size: 0.50rem; 
    }

    table, th, td {
        border: 1px solid black !important;
        border-collapse: collapse !important;
    }
    .vertical-text{
        /*transform: rotate(180deg);*/
        transform: rotate(270deg);
        transform-origin: left top 0;
    }
    .width-fecha{
        width: 90px;
        margin-top: 60px;
        margin-left: 1px;
    }

    .max-w-table {
        width: 97% !important;
    }

    .text-uppercase{
        text-transform: uppercase;
    }

    .px-1{
        padding-left: 3px;
        padding-right: 3px;
    }
    header {
        position: fixed;
        margin-top: 20px;
        left: 0px;
        right: 0px;
        height: 50px;

        /** Extra personal styles **/
        /*background-color: #03a9f4;
        color: white;
        text-align: center;
        line-height: 35px;*/
    }

    footer {
        position: fixed;
        bottom: -60px;
        left: 0px;
        right: 0px;
        height: 50px;

        /** Extra personal styles **/
        background-color: #03a9f4;
        color: white;
        text-align: center;
        line-height: 35px;
    }

    thead {
    display: table-header-group;
    }
    tfoot {
    display: table-row-group;
    }
    table {
    width: 98%;
    border-collapse: collapse;
    }
    th {
    word-break: break-all;
    word-wrap: break-word;
    }
    tr {
    page-break-inside: avoid;
    }
    </style>
    <main>
        <!-- Lunes -->
        <div class="" style="margin-bottom: 10px;">
            <table >
                <thead>
                    <tr>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 100%;" colspan="20">
                            ESTIMACION SEMANAL
                        </th>
                    </tr>
                    <tr>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 100%;" colspan="20">
                            <?php echo e($txtFechasEstimas); ?>

                        </th>
                    </tr>
                    <tr>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">Horario</th>
                        <th class="font-size-9 px-1" style="height: 12px; width: 10px;  background-color:darkgray;">Lunes</th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> 150 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> 200 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> 250 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> 300 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> 350 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> 400 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> 450 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> 500 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> Total  </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px; background-color:darkgray;"> TA </th>
                    </tr>
                </thead>
                <tbody>
                <?php if(count($datos['lunes']) > 0): ?>
                <?php $__currentLoopData = $datos['lunes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estimaPorDia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['horario']); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 50px; background-color:darkgray;"> <?php echo e($estimaPorDia['nombre_municipio']); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nPrimerPrestamo']); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoPrimerPrestamo']); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nSegundoPrestamo']); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoSegundoPrestamo']); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nTercerPrestamo']); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoTercerPrestamo']); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nCuartoPrestamo']); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoCuartoPrestamo']); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nQuintoPrestamo']); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoQuintoPrestamo']); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nSextoPrestamo']); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoSextoPrestamo']); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nSeptimoPrestamo']); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoSeptimoPrestamo']); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nOctavoPrestamo']); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoOctavoPrestamo']); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['totalMonto']); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['totalAbonos']); ?> </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">   </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 50px; background-color:darkgray;"> TOTALES </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->nPrimerPrestamo); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->montoPrimerPrestamo); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->nSegundoPrestamo); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->montoSegundoPrestamo); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->nTercerPrestamo); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->montoTercerPrestamo); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->nCuartoPrestamo); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->montoCuartoPrestamo); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->nQuintoPrestamo); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->montoQuintoPrestamo); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->nSextoPrestamo); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->montoSextoPrestamo); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->nSeptimoPrestamo); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->montoSeptimoPrestamo); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->nOctavoPrestamo); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->montoOctavoPrestamo); ?> </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->totalMonto); ?> </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['lunes']->totalAbonos); ?> </td>
                </tr>
                <?php endif; ?>
                <?php if(count($datos['lunes']) == 0): ?>
                <tr>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 50px;">  </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Martes -->
        <div class="" style="margin-bottom: 10px;">
            <table >
                <thead>
                    <tr>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">Horario</th>
                        <th class="font-size-9 px-1" style="height: 12px; width: 10px;  background-color:darkgray;">Martes</th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 150 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 200 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 250 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 300 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 350 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 400 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 450 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 500 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> Total  </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> TA </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($datos['martes']) > 0): ?>
                    <?php $__currentLoopData = $datos['martes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estimaPorDia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['horario']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 50px; background-color:darkgray;"> <?php echo e($estimaPorDia['nombre_municipio']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nPrimerPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoPrimerPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nSegundoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoSegundoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nTercerPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoTercerPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nCuartoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoCuartoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nQuintoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoQuintoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nSextoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoSextoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nSeptimoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoSeptimoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nOctavoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoOctavoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['totalMonto']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['totalAbonos']); ?> </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">   </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 50px;  background-color:darkgray;"> TOTALES </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->nPrimerPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->montoPrimerPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->nSegundoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->montoSegundoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->nTercerPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->montoTercerPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->nCuartoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->montoCuartoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->nQuintoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->montoQuintoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->nSextoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->montoSextoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->nSeptimoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->montoSeptimoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->nOctavoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->montoOctavoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->totalMonto); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['martes']->totalAbonos); ?> </td>
                    </tr>
                    <?php endif; ?>
                    <?php if(count($datos['martes']) == 0): ?>
                    <tr>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 50px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    </tr>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>

        <!-- Miercoles -->
        <div class="" style="margin-bottom: 10px;">
            <table >
                <thead>
                    <tr>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">Horario</th>
                        <th class="font-size-9 px-1" style="height: 12px; width: 10px;  background-color:darkgray;">Miercoles</th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 150 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 200 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 250 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 300 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 350 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 400 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 450 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 500 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> Total  </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> TA </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($datos['miercoles']) > 0): ?>
                    <?php $__currentLoopData = $datos['miercoles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estimaPorDia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['horario']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 50px; background-color:darkgray;"> <?php echo e($estimaPorDia['nombre_municipio']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nPrimerPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoPrimerPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nSegundoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoSegundoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nTercerPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoTercerPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nCuartoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoCuartoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nQuintoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoQuintoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nSextoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoSextoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nSeptimoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoSeptimoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nOctavoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoOctavoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['totalMonto']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['totalAbonos']); ?> </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">   </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 50px;  background-color:darkgray;"> TOTALES </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->nPrimerPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->montoPrimerPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->nSegundoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->montoSegundoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->nTercerPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->montoTercerPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->nCuartoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->montoCuartoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->nQuintoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->montoQuintoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->nSextoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->montoSextoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->nSeptimoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->montoSeptimoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->nOctavoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->montoOctavoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->totalMonto); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['miercoles']->totalAbonos); ?> </td>
                    </tr>
                    <?php endif; ?>
                    <?php if(count($datos['miercoles']) == 0): ?>
                    <tr>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 50px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    </tr>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
        
        <!-- Jueves -->
        <div class="" style="margin-bottom: 10px;">
            <table >
                <thead>
                    <tr>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">Horario</th>
                        <th class="font-size-9 px-1" style="height: 12px; width: 10px;  background-color:darkgray;">Jueves</th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 150 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 200 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 250 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 300 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 350 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 400 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 450 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 500 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> Total  </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> TA </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($datos['jueves']) > 0): ?>
                    <?php $__currentLoopData = $datos['jueves']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estimaPorDia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['horario']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 50px; background-color:darkgray;"> <?php echo e($estimaPorDia['nombre_municipio']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nPrimerPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoPrimerPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nSegundoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoSegundoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nTercerPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoTercerPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nCuartoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoCuartoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nQuintoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoQuintoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nSextoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoSextoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nSeptimoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoSeptimoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nOctavoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoOctavoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['totalMonto']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['totalAbonos']); ?> </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">   </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 50px;  background-color:darkgray;"> TOTALES </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->nPrimerPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->montoPrimerPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->nSegundoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->montoSegundoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->nTercerPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->montoTercerPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->nCuartoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->montoCuartoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->nQuintoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->montoQuintoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->nSextoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->montoSextoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->nSeptimoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->montoSeptimoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->nOctavoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->montoOctavoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->totalMonto); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['jueves']->totalAbonos); ?> </td>
                    </tr>
                    <?php endif; ?>
                    <?php if(count($datos['jueves']) == 0): ?>
                    <tr>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 50px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    </tr>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>

        <!-- Viernes -->
        <div class="" style="margin-bottom: 10px;">
            <table >
                <thead>
                    <tr>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">Horario</th>
                        <th class="font-size-9 px-1" style="height: 12px; width: 10px;  background-color:darkgray;">Viernes</th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 150 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 200 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 250 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 300 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 350 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 400 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 450 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> 500 </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> $ </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> Total  </th>
                        <th class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;  background-color:darkgray;"> TA </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($datos['viernes']) > 0): ?>
                    <?php $__currentLoopData = $datos['viernes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estimaPorDia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['horario']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 50px; background-color:darkgray;"> <?php echo e($estimaPorDia['nombre_municipio']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nPrimerPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoPrimerPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nSegundoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoSegundoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nTercerPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoTercerPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nCuartoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoCuartoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nQuintoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoQuintoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nSextoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoSextoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nSeptimoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoSeptimoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['nOctavoPrestamo']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['montoOctavoPrestamo']); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['totalMonto']); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($estimaPorDia['totalAbonos']); ?> </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">   </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 50px;  background-color:darkgray;"> TOTALES </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->nPrimerPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->montoPrimerPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->nSegundoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->montoSegundoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->nTercerPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->montoTercerPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->nCuartoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->montoCuartoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->nQuintoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->montoQuintoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->nSextoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->montoSextoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->nSeptimoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->montoSeptimoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->nOctavoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->montoOctavoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->totalMonto); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['viernes']->totalAbonos); ?> </td>
                    </tr>
                    <?php endif; ?>
                    <?php if(count($datos['viernes']) == 0): ?>
                    <tr>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 50px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;">  </td>
                    </tr>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>



        <!-- totalSemana -->
        <div class="" style="margin-bottom: 10px; margin-left:172px;">
            <table >
                <tbody>
                    <tr>
                        <!-- <td class="invisiblexd" style="height: 12px; width: 25px;"></td>
                        <td class=" invisiblexd" style="height: 12px; width: 50px;"></td> -->
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->nPrimerPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->montoPrimerPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->nSegundoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->montoSegundoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->nTercerPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->montoTercerPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->nCuartoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->montoCuartoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->nQuintoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->montoQuintoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->nSextoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->montoSextoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->nSeptimoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->montoSeptimoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->nOctavoPrestamo); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->montoOctavoPrestamo); ?> </td>
                        
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->totalMonto); ?> </td>
                        <td class="font-size-9 px-1 text-center" style="height: 12px; width: 10px;"> <?php echo e($totales['totalSemana']->totalAbonos); ?> </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="cajaExt">
            <div class="cajaFirma">
                <p style="text-align: center;">C. Carlos Barrera Arroyo</p>
            </div>
        </div>

    </main>
    
</body>
</html><?php /**PATH C:\laragon\www\prestamos\resources\views//formatos/Estimas.blade.php ENDPATH**/ ?>